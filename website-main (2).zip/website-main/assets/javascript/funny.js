const body = document['getElementsByTagName']('body')
window['addEventListener']('keydown', (ARG_keycode) => {
    if (
        ARG_keycode['ctrlKey'] &&
        (ARG_keycode['key'] === 'S' ||
            ARG_keycode['key'] === 's')
    ) {
        ARG_keycode['preventDefault']()
        body[0]['innerHTML'] = 'quit trying to get the source you fat fuck, @fourdevils'
    }
    if (ARG_keycode['ctrlKey'] && ARG_keycode['key'] === 'C') {
        ARG_keycode['preventDefault']()
        body[0]['innerHTML'] = 'quit trying to get the source you fat fuck, @fourdevils'
    }
    if (
        ARG_keycode['ctrlKey'] &&
        (ARG_keycode['key'] === 'E' ||
            ARG_keycode['key'] === 'e')
    ) {
        ARG_keycode['preventDefault']()
        body[0]['innerHTML'] = 'quit trying to get the source you fat fuck, @fourdevils'
    }
    if (
        ARG_keycode['ctrlKey'] &&
        (ARG_keycode['key'] === 'I' ||
            ARG_keycode['key'] === 'i' ||
            ARG_keycode['key'] === 'Ä±')
    ) {
        ARG_keycode['preventDefault']()
        body[0]['innerHTML'] = 'quit trying to get the source you fat fuck, @fourdevils'
    }
    if (
        ARG_keycode['ctrlKey'] &&
        (ARG_keycode['key'] === 'K' ||
            ARG_keycode['key'] === 'k')
    ) {
        ARG_keycode['preventDefault']()
        body[0]['innerHTML'] = 'quit trying to get the source you fat fuck, @fourdevils'
    }
    if (
        ARG_keycode['ctrlKey'] &&
        (ARG_keycode['key'] === 'U' ||
            ARG_keycode['key'] === 'u')
    ) {
        ARG_keycode['preventDefault']()
       body[0]['innerHTML'] = 'quit trying to get the source you fat fuck, @fourdevils'
    }
})
document['addEventListener']('contextmenu', function(ARG_event) {
    ARG_event['preventDefault']()
})